% Ejercicio 1
%! matriz(+F, +C, -M).
matriz(0,_, []).
matriz(F, C, [M | MS]) :- F > 0, length(M, C), Fm1 is F - 1, matriz(Fm1, C, MS).


% Ejercicio 2
%! replicar(+Elem, +N, -Lista).
replicar(_, 0, []).
replicar(X, N, [X | Xs]) :- N > 0, Nm1 is N-1, replicar(X, Nm1, Xs).
% Ejercicio 12: en texttt.md


% Ejercicio 3
%! transponer(+M, -MT).
transponer([], []).
transponer([[]|_], []).
transponer(M, [Fila | Filas]) :-
    maplist(headTail, M, Fila, Restos),
    transponer(Restos, Filas).

%! headTail(+List, -Head, -Tail)
headTail([H | T], H, T).


% Predicado dado armarNono/3
armarNono(RF, RC, nono(M, RS)) :-
	length(RF, F),
	length(RC, C),
	matriz(F, C, M),
	transponer(M, Mt),
	zipR(RF, M, RSFilas),
	zipR(RC, Mt, RSColumnas),
	append(RSFilas, RSColumnas, RS).

zipR([], [], []).
zipR([R|RT], [L|LT], [r(R,L)|T]) :- zipR(RT, LT, T).


% Ejercicio 4
/*
	Basándonos en el tip 3, primero vamos a crear la lista de blancos,
	que sería una versión correspondiente a la lista de negros dada por
	la restricción, y luego vamos a zipearla con la lista de negros. Eso
	nos va a dar una lista de longitud impar (si la lista de negros mide
	k, la de blancos mide k+1) que nos dirá cómo vamos a ir pintando las
	celdas, empezando por blancos, luego negros... y así alternadamente.

	Para crear la mencionada lista de blancos, vamos a generar todas las
	listas de longitud k+1 que suman `cantidad de celdas - cantidad
	de celdas negras` cuyos elementos sean >=0, y al final filtraremos
	las que tienen ceros en el medio (esas no son válidas).
*/
%! pintadasValidas(+R).
pintadasValidas(r(Negros, Celdas)) :-
	length(Celdas, CantCeldas),  
	listaBlancos(Negros, CantCeldas, Blancos),
	zip(Blancos, Negros, Pintadas), % Pintadas nos dice cuántos blancos pintar, luego cuántos negros... así alternadamente.
	pintarBlanco(Pintadas, Celdas).

%! listaBlancos(+ListaNegros, +CantCeldas, -ListaBlancos).
listaBlancos([], CantCeldas, [CantCeldas]).
listaBlancos(ListaNegros, CantCeldas, [Principio | ConFinal]) :-
	length(ListaNegros, CantNegros), sumlist(ListaNegros, SumaNegros),
	CantBlancos is CantNegros + 1, SumaBlancos is CantCeldas - SumaNegros,
	generarListasLongitudSuma(CantBlancos, SumaBlancos, [Principio | ConFinal]),
	append(Medio, [_], ConFinal), % Acá verificamos que el medio de la lista (la lista sin su head y last) tenga todos números mayores que cero
	not(member(0, Medio)).

%! generarListasLongitudSuma(+Longitud, +Suma, -Lista).
generarListasLongitudSuma(0, _, []).
generarListasLongitudSuma(Longitud, Suma, [I | Resto]) :-
	Longitud > 0, between(0, Suma, I),
	SiguienteSuma is Suma - I, Lm1 is Longitud-1,
	generarListasLongitudSuma(Lm1, SiguienteSuma, Resto),
	sumlist([I | Resto], Suma).

%! zip(+L1, +L2, -L3).
zip([], L, L).
zip([H | T], L, [H | TR]) :- zip(L, T, TR).

%! pintarBlanco(+Restricciones, -Pintado).
pintarBlanco([B | Resto], Pintado) :-
	replicar(o, B, Blancos),
	pintarNegro(Resto, RestoPintado),
	append(Blancos, RestoPintado, Pintado).

%! pintarNegro(+Restricciones, -Pintado).
pintarNegro([], []).
pintarNegro([N | Resto], Pintado) :-
	replicar(x, N, Negros),
	pintarBlanco(Resto, RestoPintado),
	append(Negros, RestoPintado, Pintado).


% Ejercicio 5
%! resolverNaive(+NN).
resolverNaive(nono(_, Restricciones)) :-
	maplist(pintadasValidas, Restricciones).


% Ejercicio 6
%! pintarObligatorias(+R).
pintarObligatorias(r(Negros, PintadasObligatorias)) :- 
	listaPintadasValidas(r(Negros, PintadasObligatorias), Pintadas),
	transponer(Pintadas, PT), % Cada celda es una columna de la matriz Pintadas; si transponemos nos quedan en filas.
	maplist(combinarCeldas, PT, PintadasObligatorias).

%! listaPintadasValidas(?R, ?L).
listaPintadasValidas(Restriccion, ListaPintadasValidas) :-
	bagof(Restriccion, pintadasValidas(Restriccion), ListaRestricciones),
	maplist(pintada, ListaRestricciones, ListaPintadasValidas).

%! combinarCeldas(+Celdas, -Celda).
combinarCeldas([C], C).
combinarCeldas([C1, C2 | Cs], C) :-
	combinarCelda(C1, C2, C3),
	combinarCeldas([C3 | Cs], C).

%! pintada(?R, ?L).
pintada(r(_, L), L).


% Predicado dado combinarCelda/3
combinarCelda(A, B, _) :- var(A), var(B).
combinarCelda(A, B, _) :- nonvar(A), var(B).
combinarCelda(A, B, _) :- var(A), nonvar(B).
combinarCelda(A, B, A) :- nonvar(A), nonvar(B), A = B.
combinarCelda(A, B, _) :- nonvar(A), nonvar(B), A \== B.


% Ejercicio 7
%! deducir1Pasada(+NN).
deducir1Pasada(nono(_, RS)) :-
	maplist(pintarObligatorias, RS).


% Predicado dado
cantidadVariablesLibres(T, N) :- term_variables(T, LV), length(LV, N).


% Predicado dado
deducirVariasPasadas(NN) :-
	NN = nono(M,_),
	cantidadVariablesLibres(M, VI), % VI = cantidad de celdas sin instanciar en M en este punto
	deducir1Pasada(NN),
	cantidadVariablesLibres(M, VF), % VF = cantidad de celdas sin instanciar en M en este punto
	deducirVariasPasadasCont(NN, VI, VF).


% Predicado dado
deducirVariasPasadasCont(_, A, A). % Si VI = VF entonces no hubo más cambios y frenamos.
deducirVariasPasadasCont(NN, A, B) :- A =\= B, deducirVariasPasadas(NN).


% Ejercicio 8
%! restriccionConMenosLibres(+NN, -R).
restriccionConMenosLibres(nono(_, Rs), R) :-
	member(R, Rs), cantidadVariablesLibres(R, CR), CR > 0,
	not((member(R2, Rs), cantidadVariablesLibres(R2, CR2), CR2 > 0, CR2 < CR)).


% Ejercicio 9
%! resolverDeduciendo(+NN).
resolverDeduciendo(NN) :-
	deducirVariasPasadas(NN), % Esta cláusula mejora significativamente la performance para los nonogramas totalmente en blanco; en particular el 15 pasa de +30 minutos a ~1 minuto.
	cantidadVariablesLibres(NN, C),
	resolverDeduciendoCont(NN, C),
	deducirVariasPasadas(NN). % Verificar que el intento sea congruente con todas las restricciones.

%! resolverDeduciendoCont(+NN, +CantFreeVariables).
resolverDeduciendoCont(_, 0). % Si tiene 0 FV, ya está resuelto.
resolverDeduciendoCont(NN, FV) :-
	FV > 0,
	restriccionConMenosLibres(NN, R), !, % Si no hay pintada que valga para una restricción, el nonograma directamente no tiene solución.
	pintadasValidas(R),
	cantidadVariablesLibres(NN, FVN),
	resolverDeduciendoCont(NN, FVN).


% Ejercicio 10
%! solucionUnica(+NN).
solucionUnica(NN) :- bagof(NN, resolverDeduciendo(NN), L), length(L, 1).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%    Ejemplos de nonogramas    %
%        NO MODIFICAR          %
%    pero se pueden agregar    %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fáciles
nn(0, NN) :- armarNono([[1],[2]],[[],[2],[1]], NN).
nn(1, NN) :- armarNono([[4],[2,1],[2,1],[1,1],[1]],[[4],[3],[1],[2],[3]], NN).
nn(2, NN) :- armarNono([[4],[3,1],[1,1],[1],[1,1]],[[4],[2],[2],[1],[3,1]], NN).
nn(3, NN) :- armarNono([[2,1],[4],[3,1],[3],[3,3],[2,1],[2,1],[4],[4,4],[4,2]], [[1,2,1],[1,1,2,2],[2,3],[1,3,3],[1,1,1,1],[2,1,1],[1,1,2],[2,1,1,2],[1,1,1],[1]], NN).
nn(4, NN) :- armarNono([[1, 1], [5], [5], [3], [1]], [[2], [4], [4], [4], [2]], NN).
nn(5, NN) :- armarNono([[], [1, 1], [], [1, 1], [3]], [[1], [1, 1], [1], [1, 1], [1]], NN).
nn(6, NN) :- armarNono([[5], [1], [1], [1], [5]], [[1, 1], [2, 2], [1, 1, 1], [1, 1], [1, 1]], NN).
nn(7, NN) :- armarNono([[1, 1], [4], [1, 3, 1], [5, 1], [3, 2], [4, 2], [5, 1], [6, 1], [2, 3, 2], [2, 6]], [[2, 1], [1, 2, 3], [9], [7, 1], [4, 5], [5], [4], [2, 1], [1, 2, 2], [4]], NN).
nn(8, NN) :- armarNono([[5], [1, 1], [1, 1, 1], [5], [7], [8, 1], [1, 8], [1, 7], [2, 5], [7]], [[4], [2, 2, 2], [1, 4, 1], [1, 5, 1], [1, 8], [1, 7], [1, 7], [2, 6], [3], [3]], NN).
nn(9, NN) :- armarNono([[4], [1, 3], [2, 2], [1, 1, 1], [3]], [[3], [1, 1, 1], [2, 2], [3, 1], [4]], NN).
nn(10, NN) :- armarNono([[1], [1], [1], [1, 1], [1, 1]], [[1, 1], [1, 1], [1], [1], [ 1]], NN).
nn(11, NN) :- armarNono([[1, 1, 1, 1], [3, 3], [1, 1], [1, 1, 1, 1], [8], [6], [10], [6], [2, 4, 2], [1, 1]], [[2, 1, 2], [4, 1, 1], [2, 4], [6], [5], [5], [6], [2, 4], [4, 1, 1], [2, 1, 2]], NN).
nn(12, NN) :- armarNono([[9], [1, 1, 1, 1], [10], [2, 1, 1], [1, 1, 1, 1], [1, 10], [1, 1, 1], [1, 1, 1], [1, 1, 1, 1, 1], [1, 9], [1, 2, 1, 1, 2], [2, 1, 1, 1, 1], [2, 1, 3, 1], [3, 1], [10]], [[], [9], [2, 2], [3, 1, 2], [1, 2, 1, 2], [3, 11], [1, 1, 1, 2, 1], [1, 1, 1, 1, 1, 1], [3, 1, 3, 1, 1], [1, 1, 1, 1, 1, 1], [1, 1, 1, 3, 1, 1], [3, 1, 1, 1, 1], [1, 1, 2, 1], [11], []], NN).
nn(13, NN) :- armarNono([[2], [1,1], [1,1], [1,1], [1], [], [2], [1,1], [1,1], [1,1], [1]], [[1], [1,3], [3,1,1], [1,1,3], [3]], NN).
nn(14, NN) :- armarNono([[1,1], [1,1], [1,1], [2]], [[2], [1,1], [1,1], [1,1]], NN).

% Una sorpresa (tarda +-60 segundos). En la última línea hay un spoiler de quién es, en caso de no reconocerlo.
nn(15, NN) :- armarNono(
	[
[	25
],[	6, 8
],[	3, 9
],[	2, 9
],[	2, 10
],[	1, 10
],[	1, 10
],[	10
],[	9
],[	9
],[	2, 7, 9
],[	3, 8, 8
],[	3, 9, 2
],[	4, 2
],[	1, 1
],[	2
],[	2
],[	
],[	4, 1
],[
],[
],[	4, 3
],[	4, 2
],[	5, 1, 3
],[	2, 2
],[	3, 2
],[	1, 4, 2
],[	13, 3
],[	15, 6
],[	10, 7
]
	],
	[
[
],[	6,2
],[	5,3
],[	3,2,1,1
],[	2,1,1,1,1
],[	2,1,1,1,1
],[	2,1,1,1,1
],[	1,3,3,2
],[	1,3,2,3
],[	1,3,1,3
],[	1,3,2,3
],[	1,4,4
],[	1,4,3
],[	1,4,3
],[	1,3,3
],[	1,1,3
],[	1,3
],[	1,4
],[	1,3
],[	8,3
],[	11,3
],[	12,1,3
],[	12,3
],[	12,2,4,2
],[	12,3,6
],[	12,1,1,5
],[	14,3
],[	11,1,2
],[	8,2
],[	1
]
	],
	NN).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%    Predicados auxiliares     %
%        NO MODIFICAR          %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%! completar(+S)
%
% Indica que se debe completar el predicado. Siempre falla.
completar(S) :- write("COMPLETAR: "), write(S), nl, fail.

%! mostrarNono(+NN)
%
% Muestra una estructura nono(...) en pantalla
% Las celdas x (pintadas) se muestran como ██.
% Las o (no pintasdas) se muestran como ░░.
% Las no instanciadas se muestran como ¿?.
mostrarNono(nono(M,_)) :- mostrarMatriz(M).

%! mostrarMatriz(+M)
%
% Muestra una matriz. Solo funciona si las celdas
% son valores x, o, o no instanciados.
mostrarMatriz(M) :-
	M = [F|_], length(F, Cols),
	mostrarBorde('╔',Cols,'╗'),
	maplist(mostrarFila, M),
	mostrarBorde('╚',Cols,'╝').

mostrarBorde(I,N,F) :-
	write(I),
	stringRepeat('══', N, S),
	write(S),
	write(F),
	nl.

stringRepeat(_, 0, '').
stringRepeat(Str, N, R) :- N > 0, Nm1 is N - 1, stringRepeat(Str, Nm1, Rm1), string_concat(Str, Rm1, R).

%! mostrarFila(+M)
%
% Muestra una lista (fila o columna). Solo funciona si las celdas
% son valores x, o, o no instanciados.
mostrarFila(Fila) :-
	write('║'),
	maplist(mostrarCelda, Fila),
	write('║'),
	nl.

mostrarCelda(C) :- nonvar(C), C = x, write('██').
mostrarCelda(C) :- nonvar(C), C = o, write('░░').
mostrarCelda(C) :- var(C), write('¿?').


%! tam(+N, -T).
tam(N, (F, C)) :- nn(N, nono([M | Ms], _)), length([M | Ms], F), length(M, C).

% El del nonograma 15 es Alan Turing, por si quedó irreconociblemente pixelado.